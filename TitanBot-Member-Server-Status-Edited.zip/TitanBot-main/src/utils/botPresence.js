/**
 * Updates the bot activity with the total member count and number of servers
 * the bot is currently in. Member totals are summed from Discord's guild
 * memberCount values; they may include the same person more than once if that
 * person belongs to multiple servers.
 */
export function updateBotPresence(client) {
  if (!client?.user || !client?.guilds?.cache) return;

  const guilds = client.guilds.cache;
  const totalMembers = guilds.reduce(
    (total, guild) => total + (Number(guild.memberCount) || 0),
    0,
  );
  const totalServers = guilds.size;

  const activityName =
    `${totalMembers.toLocaleString("en-US")} Members | ${totalServers.toLocaleString("en-US")} Servers`;

  client.user.setPresence({
    status: client.config?.bot?.presence?.status || "dnd",
    activities: [
      {
        name: activityName,
        type: 3, // Watching
      },
    ],
  });
}
