import { Events } from "discord.js";
import { updateBotPresence } from "../utils/botPresence.js";
import { logger } from "../utils/logger.js";

export default {
  name: Events.GuildDelete,
  async execute(guild, client) {
    try {
      // Discord emits this after the guild is removed from the client's cache.
      updateBotPresence(client);
      logger.info("Bot left guild; presence counts refreshed", {
        event: "guild.delete",
        guildId: guild?.id,
        guildName: guild?.name,
      });
    } catch (error) {
      logger.error("Error refreshing presence after leaving a guild:", error);
    }
  },
};
